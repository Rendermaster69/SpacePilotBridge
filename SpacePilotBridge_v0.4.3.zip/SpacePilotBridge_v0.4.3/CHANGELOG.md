# v0.4.3

- Fixes app-only updater aborting when `SpacePilotBridge.exe` is already stopped.
- Replaces `taskkill.exe` calls with PowerShell `Get-Process`/`Stop-Process`, so a missing old process is treated as normal.
- Keeps the existing executable lock/retry check before replacing the installed EXE.

# Changelog

## v0.4.2

- Fixed app-only upgrades failing because the running tray EXE was still locked.
- Updater now terminates both current/legacy SpacePilotBridge process names, waits for the installed EXE to be released, then replaces and restarts it.
- No virtual HID driver changes.

## v0.4.1

- Fixed CS0826 in `SpacePilotButtons.cs` by giving the button definition array an explicit element type.
- No driver changes; users with v0.3.3/v0.4 driver installed can use `Upgrade-App-Only.cmd`.

## v0.4.0

- Fixed virtual SpaceMouse button bits to the verified sparse SpaceMouse Pro layout.
- Added physical button catalog for all 21 original SpacePilot buttons.
- Added per-app profiles for Global, Fusion 360, Maya and ZBrush.
- Added configurable Virtual / Shortcut / BuiltIn / Disabled button actions.
- Added Speed +/- bridge sensitivity control.
- Added Dominant mode and optional bridge rotation lock.
- Added Config -> Settings default action.
- Added settings UI and persistent JSON configuration.
- Added single-instance tray app with custom icon.
- Added self-contained single-file EXE publishing.
- Replaced GDI LCD text with crisp native 5x7 monochrome pixel text.
- Added Starfield, Matrix and Bounce LCD screensavers.
- Added physical Esc screensaver cancellation with one-press suppression.
- Added app-only upgrade path that preserves the already-working virtual HID driver.

## v0.3.3

- Fixed SignTool machine certificate-store selection.

## v0.3.2

- Fixed Inf2Cat discovery across WDK architecture/version directories.

## v0.3.1

- Added persistent setup logging and resume behavior.

## v0.3

- Added software virtual HID path compatible with current 3DxWare.
- Added original SpacePilot LCD output path.
