@echo off
setlocal
TITLE SpacePilotBridge v0.4.3 App Upgrade
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\Upgrade-App-Launcher.ps1"
echo.
echo SpacePilotBridge app upgrade launcher has finished.
pause
