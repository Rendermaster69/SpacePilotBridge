using System.Buffers.Binary;
using SpacePilotBridge.Core;

namespace SpacePilotBridge.Virtual;

/// <summary>
/// Streams the physical SpacePilot state into the private control collection
/// exposed by the SpacePilotBridge virtual HID minidriver. The public HID
/// collection is intentionally shaped like a SpaceMouse Pro Wireless (cabled)
/// so current 3DxWare can consume it without per-application plug-ins.
/// </summary>
public sealed class VirtualSpaceMouseWriter : IDisposable
{
    public const ushort VendorId = 0x256F;
    public const ushort ProductId = 0xC631;
    public const byte ControlReportId = 0x7F;
    public const byte SetStateControlCode = 0x53;

    private readonly SpacePilotHub _hub;
    private readonly CancellationTokenSource _cts = new();
    private readonly Thread _thread;
    private HidFeatureDevice? _device;
    private bool _disposed;

    public bool IsConnected => _device is not null;
    public event EventHandler? ConnectionChanged;

    /// <summary>Optional app-owned motion transform (sensitivity, dominant axis, rotation lock).</summary>
    public Func<SpacePilotState, SpacePilotState>? StateTransform { get; set; }

    /// <summary>Optional app-owned physical-button to sparse virtual button bitmap mapper.</summary>
    public Func<IReadOnlyCollection<int>, uint>? ButtonMapper { get; set; }

    public VirtualSpaceMouseWriter(SpacePilotHub hub)
    {
        _hub = hub;
        _thread = new Thread(Run)
        {
            IsBackground = true,
            Name = "SpacePilot virtual SpaceMouse writer"
        };
        _thread.Start();
    }

    private void Run()
    {
        bool previous = false;
        while (!_cts.IsCancellationRequested)
        {
            try
            {
                _device ??= HidFeatureDevice.TryOpen(VendorId, ProductId, minimumFeatureReportLength: 18);
                bool now = _device is not null;
                if (now != previous)
                {
                    previous = now;
                    ConnectionChanged?.Invoke(this, EventArgs.Empty);
                }

                if (_device is null)
                {
                    _cts.Token.WaitHandle.WaitOne(500);
                    continue;
                }

                SpacePilotState state = _hub.IsConnected ? _hub.State : SpacePilotState.Zero;
                if (StateTransform is not null) state = StateTransform(state);
                byte[] report = BuildStateReport(state, ButtonMapper);
                if (!_device.WriteFeature(report))
                {
                    DropVirtualDevice(ref previous);
                    _cts.Token.WaitHandle.WaitOne(250);
                    continue;
                }

                // A fixed 125 Hz feed mirrors the cadence used by modern
                // SpaceMouse-class devices closely enough for 3DxWare while
                // also guaranteeing repeated zero reports after release.
                _cts.Token.WaitHandle.WaitOne(8);
            }
            catch
            {
                DropVirtualDevice(ref previous);
                _cts.Token.WaitHandle.WaitOne(500);
            }
        }
    }

    private void DropVirtualDevice(ref bool previous)
    {
        _device?.Dispose();
        _device = null;
        if (previous)
        {
            previous = false;
            ConnectionChanged?.Invoke(this, EventArgs.Empty);
        }
    }

    internal static byte[] BuildStateReport(SpacePilotState state, Func<IReadOnlyCollection<int>, uint>? buttonMapper = null)
    {
        var bytes = new byte[18];
        bytes[0] = ControlReportId;
        bytes[1] = SetStateControlCode;
        WriteAxis(bytes.AsSpan(2, 2), state.Tx);
        WriteAxis(bytes.AsSpan(4, 2), state.Ty);
        WriteAxis(bytes.AsSpan(6, 2), state.Tz);
        WriteAxis(bytes.AsSpan(8, 2), state.Rx);
        WriteAxis(bytes.AsSpan(10, 2), state.Ry);
        WriteAxis(bytes.AsSpan(12, 2), state.Rz);
        uint buttonBits = buttonMapper?.Invoke(state.Buttons) ?? MapButtons(state.Buttons);
        BinaryPrimitives.WriteUInt32LittleEndian(bytes.AsSpan(14, 4), buttonBits);
        return bytes;
    }

    private static void WriteAxis(Span<byte> destination, double normalized)
    {
        short value = (short)Math.Clamp((int)Math.Round(normalized * 350.0), -350, 350);
        BinaryPrimitives.WriteInt16LittleEndian(destination, value);
    }

    /// <summary>
    /// Verified SpacePilot (046D:C625) -> SpaceMouse Pro Wireless button map.
    /// The target bitmap is sparse: e.g. key 1 is bit 12 and Esc is bit 22.
    /// Source-only buttons (5, 6, Left, +, -, Dominant, Config) intentionally
    /// remain unmapped so the tray app can give them useful software actions.
    /// </summary>
    private static uint MapButtons(IReadOnlyCollection<int> sourceButtons)
    {
        uint result = 0;
        foreach (int raw in sourceButtons)
        {
            int? target = SpacePilotButtons.GetDefaultVirtualBit(raw);
            if (target is >= 0 and < 32) result |= 1u << target.Value;
        }
        return result;
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        _cts.Cancel();
        _thread.Join(1000);
        _device?.Dispose();
        _cts.Dispose();
    }
}
