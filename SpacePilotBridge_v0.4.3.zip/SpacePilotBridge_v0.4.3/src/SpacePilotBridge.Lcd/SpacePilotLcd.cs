using SpacePilotBridge.Core;

namespace SpacePilotBridge.Lcd;

/// <summary>
/// Crisp framebuffer driver for the original SpacePilot 240x64 monochrome LCD.
/// Text is drawn with a native 5x7 bitmap font so no anti-aliased pixels are
/// lost when the frame is converted to the panel's 1-bit column format.
/// </summary>
public sealed class SpacePilotLcd : IDisposable
{
    public const int Width = 240;
    public const int Height = 64;

    private HidFeatureDevice? _device;
    private bool _suppressed;
    private readonly Random _random = new();
    private readonly Star[] _stars = new Star[34];
    private readonly int[] _matrixY = new int[38];
    private bool _animationInitialized;

    public bool IsConnected => _device is not null;

    public bool EnsureConnected()
    {
        if (_device is not null) return true;
        _device = HidFeatureDevice.TryOpen(SpacePilotHub.VendorId, SpacePilotHub.ProductId, 8);
        _suppressed = false;
        return _device is not null;
    }

    public bool ShowStatus(
        string activeApp,
        bool sourceConnected,
        bool virtualConnected,
        IReadOnlyCollection<int>? buttons,
        double sensitivity,
        bool dominant,
        bool rotationLocked,
        string profileName)
    {
        var c = new MonoCanvas(Width, Height);
        string app = PrettyAppName(activeApp);
        string ready = sourceConnected && virtualConnected ? "READY" : sourceConnected ? "VHID OFF" : "OFFLINE";

        c.DrawText(app, 2, 1, 2);
        int readyWidth = c.MeasureText(ready, 1);
        c.DrawText(ready, Width - readyWidth - 2, 3, 1);
        c.HLine(1, 17, Width - 2);

        c.DrawText($"SPEED {sensitivity:0.00}X", 2, 21, 1);
        c.DrawText($"DOM {(dominant ? "ON" : "OFF")}", 88, 21, 1);
        c.DrawText($"ROT {(rotationLocked ? "LOCK" : "FREE")}", 148, 21, 1);

        c.DrawText($"PROFILE {profileName.ToUpperInvariant()}", 2, 32, 1);
        c.DrawText(FormatButtons(buttons), 2, 43, 1);

        c.HLine(1, 53, Width - 2);
        c.DrawText("SPB 0.4.1", 2, 56, 1);
        string time = DateTime.Now.ToString("HH:mm");
        c.DrawText(time, Width - c.MeasureText(time, 1) - 2, 56, 1);

        return WriteCanvas(c);
    }

    public bool ShowAnimation(string animation, int frame)
    {
        if (!_animationInitialized)
        {
            InitAnimations();
            _animationInitialized = true;
        }

        var c = new MonoCanvas(Width, Height);
        switch ((animation ?? string.Empty).Trim().ToLowerInvariant())
        {
            case "matrix": DrawMatrix(c, frame); break;
            case "bounce": DrawBounce(c, frame); break;
            default: DrawStarfield(c, frame); break;
        }
        return WriteCanvas(c);
    }

    public bool ShowMessage(string title, string line2 = "", string line3 = "")
    {
        var c = new MonoCanvas(Width, Height);
        c.DrawText(title.ToUpperInvariant(), 2, 6, 2);
        if (!string.IsNullOrWhiteSpace(line2)) c.DrawText(line2.ToUpperInvariant(), 2, 31, 1);
        if (!string.IsNullOrWhiteSpace(line3)) c.DrawText(line3.ToUpperInvariant(), 2, 45, 1);
        return WriteCanvas(c);
    }

    private void InitAnimations()
    {
        for (int i = 0; i < _stars.Length; i++)
            _stars[i] = new Star(_random.Next(Width), _random.Next(Height), _random.Next(1, 4));
        for (int i = 0; i < _matrixY.Length; i++) _matrixY[i] = _random.Next(-64, 64);
    }

    private void DrawStarfield(MonoCanvas c, int frame)
    {
        int cx = Width / 2, cy = Height / 2;
        for (int i = 0; i < _stars.Length; i++)
        {
            Star s = _stars[i];
            int dx = s.X - cx;
            int dy = s.Y - cy;
            s.X += Math.Sign(dx == 0 ? (i % 2 == 0 ? 1 : -1) : dx) * s.Speed;
            s.Y += Math.Sign(dy == 0 ? (i % 3 == 0 ? 1 : -1) : dy) * Math.Max(1, s.Speed / 2);
            if (s.X < 0 || s.X >= Width || s.Y < 0 || s.Y >= Height)
                s = new Star(cx + _random.Next(-8, 9), cy + _random.Next(-5, 6), _random.Next(1, 4));
            _stars[i] = s;
            c.Set(s.X, s.Y);
            if (s.Speed >= 3 && s.X + 1 < Width) c.Set(s.X + 1, s.Y);
        }
        if ((frame / 12) % 2 == 0) c.DrawText("SPACEPILOT", 90, 55, 1);
    }

    private void DrawMatrix(MonoCanvas c, int frame)
    {
        for (int col = 0; col < _matrixY.Length; col++)
        {
            if ((frame + col) % 2 == 0) _matrixY[col] += 2 + (col % 3);
            if (_matrixY[col] > Height + 18) _matrixY[col] = _random.Next(-36, -4);
            int x = col * 6 + 2;
            for (int tail = 0; tail < 4; tail++)
            {
                int y = _matrixY[col] - tail * 9;
                if (y < -7 || y >= Height) continue;
                char ch = (char)('0' + ((frame + col * 7 + tail * 3) % 10));
                c.DrawText(ch.ToString(), x, y, 1);
            }
        }
    }

    private static void DrawBounce(MonoCanvas c, int frame)
    {
        int maxX = Width - 34;
        int maxY = Height - 18;
        int periodX = maxX * 2;
        int periodY = maxY * 2;
        int px = (frame * 5) % periodX;
        int py = (frame * 3) % periodY;
        int x = px <= maxX ? px : periodX - px;
        int y = py <= maxY ? py : periodY - py;
        c.Rect(x, y, 34, 18);
        c.DrawText("SPB", x + 7, y + 6, 1);
    }

    private static string PrettyAppName(string activeApp)
    {
        if (string.IsNullOrWhiteSpace(activeApp)) return "SPACEPILOT";
        string name = Path.GetFileNameWithoutExtension(activeApp).Trim();
        string n = name.ToLowerInvariant();
        if (n.Contains("fusion")) return "FUSION 360";
        if (n.Contains("maya")) return "MAYA";
        if (n.Contains("zbrush")) return "ZBRUSH";
        return name.ToUpperInvariant();
    }

    private static string FormatButtons(IReadOnlyCollection<int>? buttons)
    {
        if (buttons is null || buttons.Count == 0) return "KEYS -";
        return "KEYS " + string.Join("+", buttons.Take(5).Select(SpacePilotButtons.GetName)).ToUpperInvariant();
    }

    private bool WriteCanvas(MonoCanvas canvas)
    {
        if (!EnsureConnected() || _device is null) return false;
        try
        {
            if (!_suppressed)
            {
                if (!_device.WriteFeature(new byte[] { 0x12, 0x00, 0x00, 0x2F, 0, 0, 0, 0 })) return false;
                _suppressed = true;
            }

            for (int page = 0; page < 8; page++)
            {
                if (!_device.WriteFeature(new byte[] { 0x0C, (byte)page, 0x00, 0x00, 0, 0, 0, 0 })) return false;
                for (int col = 0; col < Width; col += 7)
                {
                    var report = new byte[8];
                    report[0] = 0x0D;
                    for (int i = 0; i < 7; i++)
                    {
                        int x = col + i;
                        if (x >= Width) break;
                        byte column = 0;
                        for (int bit = 0; bit < 8; bit++)
                        {
                            int y = page * 8 + bit;
                            if (canvas.Get(x, y)) column |= (byte)(1 << bit);
                        }
                        report[i + 1] = column;
                    }
                    if (!_device.WriteFeature(report)) return false;
                }
            }
            return true;
        }
        catch
        {
            Disconnect();
            return false;
        }
    }

    private void Disconnect()
    {
        _device?.Dispose();
        _device = null;
        _suppressed = false;
    }

    public void Dispose() => Disconnect();

    private struct Star
    {
        public int X;
        public int Y;
        public int Speed;
        public Star(int x, int y, int speed) { X = x; Y = y; Speed = speed; }
    }
}

internal sealed class MonoCanvas
{
    private readonly bool[] _pixels;
    public int Width { get; }
    public int Height { get; }

    public MonoCanvas(int width, int height)
    {
        Width = width;
        Height = height;
        _pixels = new bool[width * height];
    }

    public void Set(int x, int y, bool value = true)
    {
        if ((uint)x >= Width || (uint)y >= Height) return;
        _pixels[y * Width + x] = value;
    }

    public bool Get(int x, int y) => (uint)x < Width && (uint)y < Height && _pixels[y * Width + x];

    public void HLine(int x1, int y, int x2)
    {
        for (int x = Math.Max(0, x1); x <= Math.Min(Width - 1, x2); x++) Set(x, y);
    }

    public void Rect(int x, int y, int w, int h)
    {
        HLine(x, y, x + w - 1);
        HLine(x, y + h - 1, x + w - 1);
        for (int yy = y; yy < y + h; yy++) { Set(x, yy); Set(x + w - 1, yy); }
    }

    public int MeasureText(string text, int scale = 1) => string.IsNullOrEmpty(text) ? 0 : text.Length * 6 * scale - scale;

    public void DrawText(string text, int x, int y, int scale = 1)
    {
        int cursor = x;
        foreach (char raw in text)
        {
            char ch = char.ToUpperInvariant(raw);
            byte[] glyph = PixelFont.Get(ch);
            for (int col = 0; col < 5; col++)
            {
                byte bits = glyph[col];
                for (int row = 0; row < 7; row++)
                {
                    if ((bits & (1 << row)) == 0) continue;
                    for (int sx = 0; sx < scale; sx++)
                        for (int sy = 0; sy < scale; sy++)
                            Set(cursor + col * scale + sx, y + row * scale + sy);
                }
            }
            cursor += 6 * scale;
            if (cursor >= Width) break;
        }
    }
}

internal static class PixelFont
{
    private static readonly Dictionary<char, byte[]> Glyphs = new()
    {
        [' '] = G("00000","00000","00000","00000","00000","00000","00000"),
        ['A'] = G("01110","10001","10001","11111","10001","10001","10001"),
        ['B'] = G("11110","10001","10001","11110","10001","10001","11110"),
        ['C'] = G("01111","10000","10000","10000","10000","10000","01111"),
        ['D'] = G("11110","10001","10001","10001","10001","10001","11110"),
        ['E'] = G("11111","10000","10000","11110","10000","10000","11111"),
        ['F'] = G("11111","10000","10000","11110","10000","10000","10000"),
        ['G'] = G("01111","10000","10000","10111","10001","10001","01111"),
        ['H'] = G("10001","10001","10001","11111","10001","10001","10001"),
        ['I'] = G("11111","00100","00100","00100","00100","00100","11111"),
        ['J'] = G("00111","00010","00010","00010","10010","10010","01100"),
        ['K'] = G("10001","10010","10100","11000","10100","10010","10001"),
        ['L'] = G("10000","10000","10000","10000","10000","10000","11111"),
        ['M'] = G("10001","11011","10101","10101","10001","10001","10001"),
        ['N'] = G("10001","11001","10101","10011","10001","10001","10001"),
        ['O'] = G("01110","10001","10001","10001","10001","10001","01110"),
        ['P'] = G("11110","10001","10001","11110","10000","10000","10000"),
        ['Q'] = G("01110","10001","10001","10001","10101","10010","01101"),
        ['R'] = G("11110","10001","10001","11110","10100","10010","10001"),
        ['S'] = G("01111","10000","10000","01110","00001","00001","11110"),
        ['T'] = G("11111","00100","00100","00100","00100","00100","00100"),
        ['U'] = G("10001","10001","10001","10001","10001","10001","01110"),
        ['V'] = G("10001","10001","10001","10001","10001","01010","00100"),
        ['W'] = G("10001","10001","10001","10101","10101","10101","01010"),
        ['X'] = G("10001","10001","01010","00100","01010","10001","10001"),
        ['Y'] = G("10001","10001","01010","00100","00100","00100","00100"),
        ['Z'] = G("11111","00001","00010","00100","01000","10000","11111"),
        ['0'] = G("01110","10001","10011","10101","11001","10001","01110"),
        ['1'] = G("00100","01100","00100","00100","00100","00100","01110"),
        ['2'] = G("01110","10001","00001","00010","00100","01000","11111"),
        ['3'] = G("11110","00001","00001","01110","00001","00001","11110"),
        ['4'] = G("00010","00110","01010","10010","11111","00010","00010"),
        ['5'] = G("11111","10000","10000","11110","00001","00001","11110"),
        ['6'] = G("01110","10000","10000","11110","10001","10001","01110"),
        ['7'] = G("11111","00001","00010","00100","01000","01000","01000"),
        ['8'] = G("01110","10001","10001","01110","10001","10001","01110"),
        ['9'] = G("01110","10001","10001","01111","00001","00001","01110"),
        ['-'] = G("00000","00000","00000","11111","00000","00000","00000"),
        ['+'] = G("00000","00100","00100","11111","00100","00100","00000"),
        ['.'] = G("00000","00000","00000","00000","00000","01100","01100"),
        [':'] = G("00000","01100","01100","00000","01100","01100","00000"),
        ['/'] = G("00001","00010","00010","00100","01000","01000","10000"),
        ['='] = G("00000","11111","00000","11111","00000","00000","00000"),
        ['_'] = G("00000","00000","00000","00000","00000","00000","11111"),
        ['?'] = G("01110","10001","00001","00010","00100","00000","00100"),
        ['%'] = G("11001","11010","00100","01000","10110","00110","00000"),
        ['('] = G("00010","00100","01000","01000","01000","00100","00010"),
        [')'] = G("01000","00100","00010","00010","00010","00100","01000"),
        ['['] = G("01110","01000","01000","01000","01000","01000","01110"),
        [']'] = G("01110","00010","00010","00010","00010","00010","01110"),
    };

    public static byte[] Get(char c) => Glyphs.TryGetValue(c, out var g) ? g : Glyphs['?'];

    private static byte[] G(params string[] rows)
    {
        var cols = new byte[5];
        for (int y = 0; y < Math.Min(7, rows.Length); y++)
            for (int x = 0; x < Math.Min(5, rows[y].Length); x++)
                if (rows[y][x] == '1') cols[x] |= (byte)(1 << y);
        return cols;
    }
}
