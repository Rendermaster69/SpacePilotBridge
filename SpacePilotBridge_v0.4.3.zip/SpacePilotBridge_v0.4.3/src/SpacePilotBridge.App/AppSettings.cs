using System.Text.Json.Serialization;

namespace SpacePilotBridge.App;

internal sealed class BridgeSettings
{
    public double Sensitivity { get; set; } = 1.0;
    public double SensitivityStep { get; set; } = 0.10;
    public bool DominantMode { get; set; }
    public bool RotationLocked { get; set; }
    public string DefaultScreensaver { get; set; } = "Starfield";
    public Dictionary<string, ProfileSettings> Profiles { get; set; } = new(StringComparer.OrdinalIgnoreCase);

    public static BridgeSettings CreateDefaults()
    {
        var settings = new BridgeSettings();
        var global = new ProfileSettings();
        global.Buttons[16] = ButtonBinding.BuiltIn("IncreaseSensitivity");
        global.Buttons[17] = ButtonBinding.BuiltIn("DecreaseSensitivity");
        global.Buttons[18] = ButtonBinding.BuiltIn("ToggleDominant");
        global.Buttons[20] = ButtonBinding.BuiltIn("OpenSettings");
        settings.Profiles["global"] = global;
        settings.Profiles["fusion"] = new ProfileSettings();
        settings.Profiles["maya"] = new ProfileSettings();
        settings.Profiles["zbrush"] = new ProfileSettings();
        return settings;
    }
}

internal sealed class ProfileSettings
{
    public Dictionary<int, ButtonBinding> Buttons { get; set; } = new();
}

internal sealed class ButtonBinding
{
    /// <summary>Inherit, Default, Virtual, Shortcut, BuiltIn or Disabled.</summary>
    public string Mode { get; set; } = "Inherit";
    public string Value { get; set; } = string.Empty;

    [JsonIgnore]
    public bool IsEmpty => string.IsNullOrWhiteSpace(Mode) || Mode.Equals("Inherit", StringComparison.OrdinalIgnoreCase);

    public static ButtonBinding Default() => new() { Mode = "Default" };
    public static ButtonBinding Virtual(string target) => new() { Mode = "Virtual", Value = target };
    public static ButtonBinding Shortcut(string shortcut) => new() { Mode = "Shortcut", Value = shortcut };
    public static ButtonBinding BuiltIn(string action) => new() { Mode = "BuiltIn", Value = action };
    public static ButtonBinding Disabled() => new() { Mode = "Disabled" };
    public static ButtonBinding Inherit() => new() { Mode = "Inherit" };
}
