using System.Drawing;
using SpacePilotBridge.Core;

namespace SpacePilotBridge.App;

internal sealed class SettingsForm : Form
{
    private readonly ButtonActionEngine _engine;
    private readonly ComboBox _profile = new();
    private readonly DataGridView _grid = new();
    private readonly NumericUpDown _sensitivity = new();
    private readonly NumericUpDown _step = new();
    private readonly CheckBox _dominant = new();
    private readonly CheckBox _rotation = new();
    private readonly ComboBox _defaultScreensaver = new();
    private readonly Label _liveButton = new();
    private bool _loading;

    public event EventHandler? Saved;

    public SettingsForm(ButtonActionEngine engine)
    {
        _engine = engine;
        Text = "SpacePilotBridge 0.4.1";
        Width = 850;
        Height = 650;
        MinimumSize = new Size(760, 560);
        StartPosition = FormStartPosition.CenterScreen;
        Icon = TrayIconFactory.CreateIcon();

        var tabs = new TabControl { Dock = DockStyle.Fill };
        tabs.TabPages.Add(BuildButtonsTab());
        tabs.TabPages.Add(BuildGeneralTab());
        tabs.TabPages.Add(BuildScreensaverTab());

        var bottom = new FlowLayoutPanel
        {
            Dock = DockStyle.Bottom,
            Height = 48,
            FlowDirection = FlowDirection.RightToLeft,
            Padding = new Padding(8)
        };
        var save = new Button { Text = "Save", Width = 100, Height = 28 };
        save.Click += (_, _) => SaveAll();
        var close = new Button { Text = "Close", Width = 100, Height = 28 };
        close.Click += (_, _) => Hide();
        bottom.Controls.Add(save);
        bottom.Controls.Add(close);

        Controls.Add(tabs);
        Controls.Add(bottom);

        _engine.SettingsChanged += (_, _) => BeginInvokeIfNeeded(LoadGeneral);
        LoadGeneral();
        LoadProfile("global");
    }

    private TabPage BuildButtonsTab()
    {
        var page = new TabPage("Button mapping");
        var top = new Panel { Dock = DockStyle.Top, Height = 72, Padding = new Padding(10) };
        top.Controls.Add(new Label { Text = "Profile:", AutoSize = true, Location = new Point(10, 13) });

        _profile.DropDownStyle = ComboBoxStyle.DropDownList;
        _profile.Items.AddRange(new object[] { "Global", "Fusion 360", "Maya", "ZBrush" });
        _profile.SelectedIndex = 0;
        _profile.Location = new Point(70, 9);
        _profile.Width = 160;
        _profile.SelectedIndexChanged += (_, _) =>
        {
            if (!_loading) LoadProfile(SelectedProfileKey());
        };
        top.Controls.Add(_profile);

        _liveButton.Text = "Press a SpacePilot button to identify it";
        _liveButton.AutoSize = true;
        _liveButton.Location = new Point(260, 13);
        top.Controls.Add(_liveButton);

        var hint = new Label
        {
            AutoSize = true,
            Location = new Point(10, 42),
            Text = "Shortcut example: Ctrl+Shift+S   |   BuiltIn: IncreaseSensitivity, DecreaseSensitivity, ToggleDominant, ToggleRotationLock, OpenSettings, StartStarfield, StartMatrix, StartBounce"
        };
        top.Controls.Add(hint);

        _grid.Dock = DockStyle.Fill;
        _grid.AllowUserToAddRows = false;
        _grid.AllowUserToDeleteRows = false;
        _grid.RowHeadersVisible = false;
        _grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        _grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        _grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Physical SpacePilot button", ReadOnly = true, FillWeight = 28 });
        var behavior = new DataGridViewComboBoxColumn { HeaderText = "Behavior", FillWeight = 22, FlatStyle = FlatStyle.Flat };
        behavior.Items.AddRange("Inherit", "Default", "Virtual", "Shortcut", "BuiltIn", "Disabled");
        _grid.Columns.Add(behavior);
        _grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Assignment", FillWeight = 36 });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Default virtual target", ReadOnly = true, FillWeight = 24 });

        foreach (var b in SpacePilotButtons.All)
        {
            int row = _grid.Rows.Add(b.Name, "Inherit", string.Empty, b.DefaultVirtualName ?? "software only");
            _grid.Rows[row].Tag = b.RawId;
        }

        var reset = new Button { Text = "Reset this profile", Dock = DockStyle.Bottom, Height = 32 };
        reset.Click += (_, _) =>
        {
            foreach (DataGridViewRow row in _grid.Rows)
            {
                row.Cells[1].Value = SelectedProfileKey() == "global" ? "Default" : "Inherit";
                row.Cells[2].Value = string.Empty;
            }
            if (SelectedProfileKey() == "global")
            {
                SetRow(16, "BuiltIn", "IncreaseSensitivity");
                SetRow(17, "BuiltIn", "DecreaseSensitivity");
                SetRow(18, "BuiltIn", "ToggleDominant");
                SetRow(20, "BuiltIn", "OpenSettings");
            }
        };

        page.Controls.Add(_grid);
        page.Controls.Add(reset);
        page.Controls.Add(top);
        return page;
    }

    private TabPage BuildGeneralTab()
    {
        var page = new TabPage("General");
        var layout = new TableLayoutPanel
        {
            Dock = DockStyle.Top,
            AutoSize = true,
            ColumnCount = 2,
            Padding = new Padding(18),
        };
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 230));
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 240));

        _sensitivity.DecimalPlaces = 2;
        _sensitivity.Minimum = 0.10m;
        _sensitivity.Maximum = 3.00m;
        _sensitivity.Increment = 0.05m;
        _sensitivity.Width = 120;
        _step.DecimalPlaces = 2;
        _step.Minimum = 0.05m;
        _step.Maximum = 0.50m;
        _step.Increment = 0.05m;
        _step.Width = 120;
        _dominant.Text = "Use strongest axis only";
        _rotation.Text = "Disable rotation axes";
        _defaultScreensaver.DropDownStyle = ComboBoxStyle.DropDownList;
        _defaultScreensaver.Items.AddRange(new object[] { "Starfield", "Matrix", "Bounce" });
        _defaultScreensaver.Width = 160;

        AddRow(layout, "Global 6DOF sensitivity", _sensitivity);
        AddRow(layout, "Speed +/- step", _step);
        AddRow(layout, "Dominant mode", _dominant);
        AddRow(layout, "Rotation lock", _rotation);
        AddRow(layout, "Default LCD screensaver", _defaultScreensaver);

        var note = new Label
        {
            Text = "6DOF motion always remains native virtual SpaceMouse HID. Only buttons assigned to Shortcut use Windows keyboard input.",
            AutoSize = true,
            MaximumSize = new Size(650, 0),
            Margin = new Padding(18, 22, 18, 0)
        };
        page.Controls.Add(note);
        page.Controls.Add(layout);
        return page;
    }

    private TabPage BuildScreensaverTab()
    {
        var page = new TabPage("LCD screensavers");
        var p = new FlowLayoutPanel
        {
            Dock = DockStyle.Top,
            Height = 90,
            Padding = new Padding(18),
            FlowDirection = FlowDirection.LeftToRight
        };
        foreach (string name in new[] { "Starfield", "Matrix", "Bounce" })
        {
            var b = new Button { Text = $"Start {name}", Width = 150, Height = 34, Tag = name };
            b.Click += (_, _) => _engine.StartScreensaver((string)b.Tag!);
            p.Controls.Add(b);
        }
        var stop = new Button { Text = "Stop", Width = 100, Height = 34 };
        stop.Click += (_, _) => _engine.StopScreensaver();
        p.Controls.Add(stop);

        var info = new Label
        {
            Dock = DockStyle.Top,
            Height = 80,
            Padding = new Padding(18, 6, 18, 6),
            Text = "A screensaver stays on the physical SpacePilot LCD until you press the physical Esc button, choose Stop here, or stop it from the tray menu. While Esc is used to stop a screensaver it is swallowed once, so it will not also cancel something in Fusion/Maya/ZBrush."
        };
        page.Controls.Add(info);
        page.Controls.Add(p);
        return page;
    }

    public void NotifyPhysicalButton(int raw)
    {
        BeginInvokeIfNeeded(() => _liveButton.Text = $"Last button: {SpacePilotButtons.GetName(raw)}  (raw {raw})");
    }

    private void LoadGeneral()
    {
        var s = _engine.Settings;
        _loading = true;
        try
        {
            _sensitivity.Value = (decimal)Math.Clamp(s.Sensitivity, 0.10, 3.00);
            _step.Value = (decimal)Math.Clamp(s.SensitivityStep, 0.05, 0.50);
            _dominant.Checked = s.DominantMode;
            _rotation.Checked = s.RotationLocked;
            _defaultScreensaver.SelectedItem = s.DefaultScreensaver;
            if (_defaultScreensaver.SelectedIndex < 0) _defaultScreensaver.SelectedIndex = 0;
        }
        finally { _loading = false; }
    }

    private void LoadProfile(string profile)
    {
        _loading = true;
        try
        {
            foreach (DataGridViewRow row in _grid.Rows)
            {
                int raw = (int)row.Tag!;
                ButtonBinding? binding = null;
                if (_engine.Settings.Profiles.TryGetValue(profile, out var p) && p.Buttons.TryGetValue(raw, out var b))
                    binding = b;

                if (binding is null)
                {
                    row.Cells[1].Value = profile == "global" ? "Default" : "Inherit";
                    row.Cells[2].Value = string.Empty;
                }
                else
                {
                    row.Cells[1].Value = binding.Mode;
                    row.Cells[2].Value = binding.Value;
                }
            }
        }
        finally { _loading = false; }
    }

    private void SaveAll()
    {
        var s = _engine.Settings;
        s.Sensitivity = (double)_sensitivity.Value;
        s.SensitivityStep = (double)_step.Value;
        s.DominantMode = _dominant.Checked;
        s.RotationLocked = _rotation.Checked;
        s.DefaultScreensaver = _defaultScreensaver.SelectedItem?.ToString() ?? "Starfield";

        string profile = SelectedProfileKey();
        if (!s.Profiles.TryGetValue(profile, out var p)) s.Profiles[profile] = p = new ProfileSettings();
        p.Buttons.Clear();
        foreach (DataGridViewRow row in _grid.Rows)
        {
            int raw = (int)row.Tag!;
            string mode = row.Cells[1].Value?.ToString() ?? "Inherit";
            string value = row.Cells[2].Value?.ToString()?.Trim() ?? string.Empty;
            if (mode.Equals("Inherit", StringComparison.OrdinalIgnoreCase)) continue;
            if (profile == "global" && mode.Equals("Default", StringComparison.OrdinalIgnoreCase)) continue;
            p.Buttons[raw] = new ButtonBinding { Mode = mode, Value = value };
        }

        SettingsStore.Save(s);
        _engine.ReplaceSettings(s);
        Saved?.Invoke(this, EventArgs.Empty);
        MessageBox.Show(this, "Settings saved.", "SpacePilotBridge", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }

    private void SetRow(int raw, string mode, string value)
    {
        foreach (DataGridViewRow row in _grid.Rows)
        {
            if ((int)row.Tag! != raw) continue;
            row.Cells[1].Value = mode;
            row.Cells[2].Value = value;
            return;
        }
    }

    private string SelectedProfileKey() => _profile.SelectedIndex switch
    {
        1 => "fusion",
        2 => "maya",
        3 => "zbrush",
        _ => "global"
    };

    private static void AddRow(TableLayoutPanel layout, string label, Control control)
    {
        int row = layout.RowCount++;
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 42));
        layout.Controls.Add(new Label { Text = label, AutoSize = true, Anchor = AnchorStyles.Left }, 0, row);
        control.Anchor = AnchorStyles.Left;
        layout.Controls.Add(control, 1, row);
    }

    private void BeginInvokeIfNeeded(Action action)
    {
        if (IsDisposed) return;
        if (InvokeRequired) BeginInvoke(action);
        else action();
    }

    protected override void OnFormClosing(FormClosingEventArgs e)
    {
        if (e.CloseReason == CloseReason.UserClosing)
        {
            e.Cancel = true;
            Hide();
            return;
        }
        base.OnFormClosing(e);
    }
}
