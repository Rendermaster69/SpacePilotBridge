using System.Text.Json;

namespace SpacePilotBridge.App;

internal static class SettingsStore
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true,
        PropertyNameCaseInsensitive = true
    };

    public static string DirectoryPath => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "SpacePilotBridge");

    public static string FilePath => Path.Combine(DirectoryPath, "settings.json");

    public static BridgeSettings Load()
    {
        try
        {
            if (File.Exists(FilePath))
            {
                var settings = JsonSerializer.Deserialize<BridgeSettings>(File.ReadAllText(FilePath), JsonOptions);
                if (settings is not null)
                {
                    Normalize(settings);
                    return settings;
                }
            }
        }
        catch
        {
            // Preserve a bad file for troubleshooting instead of preventing startup.
            try
            {
                Directory.CreateDirectory(DirectoryPath);
                if (File.Exists(FilePath))
                    File.Copy(FilePath, Path.Combine(DirectoryPath, $"settings-bad-{DateTime.Now:yyyyMMdd-HHmmss}.json"), true);
            }
            catch { }
        }

        var defaults = BridgeSettings.CreateDefaults();
        Save(defaults);
        return defaults;
    }

    public static void Save(BridgeSettings settings)
    {
        Normalize(settings);
        Directory.CreateDirectory(DirectoryPath);
        string temp = FilePath + ".tmp";
        File.WriteAllText(temp, JsonSerializer.Serialize(settings, JsonOptions));
        File.Move(temp, FilePath, true);
    }

    private static void Normalize(BridgeSettings settings)
    {
        settings.Sensitivity = Math.Clamp(settings.Sensitivity, 0.10, 3.00);
        settings.SensitivityStep = Math.Clamp(settings.SensitivityStep, 0.05, 0.50);
        settings.DefaultScreensaver = string.IsNullOrWhiteSpace(settings.DefaultScreensaver)
            ? "Starfield"
            : settings.DefaultScreensaver;

        settings.Profiles ??= new Dictionary<string, ProfileSettings>(StringComparer.OrdinalIgnoreCase);
        if (settings.Profiles.Comparer != StringComparer.OrdinalIgnoreCase)
            settings.Profiles = new Dictionary<string, ProfileSettings>(settings.Profiles, StringComparer.OrdinalIgnoreCase);

        foreach (string required in new[] { "global", "fusion", "maya", "zbrush" })
            settings.Profiles.TryAdd(required, new ProfileSettings());

        // Upgrade older/default files with the useful hardware-only buttons.
        var global = settings.Profiles["global"];
        global.Buttons.TryAdd(16, ButtonBinding.BuiltIn("IncreaseSensitivity"));
        global.Buttons.TryAdd(17, ButtonBinding.BuiltIn("DecreaseSensitivity"));
        global.Buttons.TryAdd(18, ButtonBinding.BuiltIn("ToggleDominant"));
        global.Buttons.TryAdd(20, ButtonBinding.BuiltIn("OpenSettings"));
    }
}
