using SpacePilotBridge.Core;
using SpacePilotBridge.Lcd;
using SpacePilotBridge.Virtual;

namespace SpacePilotBridge.App;

internal sealed class BridgeApplicationContext : ApplicationContext
{
    private readonly SpacePilotHub _hub = SpacePilotHub.Instance;
    private readonly VirtualSpaceMouseWriter _virtual;
    private readonly SpacePilotLcd _lcd = new();
    private readonly NotifyIcon _tray;
    private readonly System.Windows.Forms.Timer _timer;
    private readonly ButtonActionEngine _actions;
    private SettingsForm? _settingsForm;

    private string _lastApp = string.Empty;
    private string _lastProfile = "global";
    private string _lastLcdSignature = string.Empty;
    private DateTime _lastLcdWrite = DateTime.MinValue;
    private DateTime _lastForegroundPoll = DateTime.MinValue;
    private DateTime _lastAnimationWrite = DateTime.MinValue;
    private int _animationFrame;
    private volatile bool _openSettingsPending;
    private volatile int _lastPressedRaw = -1;
    private string? _pendingToast;

    public BridgeApplicationContext()
    {
        BridgeSettings settings = SettingsStore.Load();
        _hub.Acquire();
        _actions = new ButtonActionEngine(_hub, settings);
        _virtual = new VirtualSpaceMouseWriter(_hub)
        {
            StateTransform = _actions.TransformState,
            ButtonMapper = _actions.MapVirtualButtons
        };

        var menu = BuildTrayMenu();
        _tray = new NotifyIcon
        {
            Text = "SpacePilotBridge",
            Icon = TrayIconFactory.CreateIcon(),
            Visible = true,
            ContextMenuStrip = menu
        };
        _tray.DoubleClick += (_, _) => ShowSettings();

        _actions.OpenSettingsRequested += (_, _) => _openSettingsPending = true;
        _actions.SettingsChanged += (_, _) => _lastLcdSignature = string.Empty;
        _actions.ScreensaverChanged += (_, _) =>
        {
            _lastLcdSignature = string.Empty;
            _animationFrame = 0;
            _lastAnimationWrite = DateTime.MinValue;
        };
        _actions.ToastRequested += text => _pendingToast = text;
        _actions.PhysicalButtonPressed += raw => _lastPressedRaw = raw;

        _hub.ConnectionChanged += (_, _) => _lastLcdSignature = string.Empty;
        _virtual.ConnectionChanged += (_, _) => _lastLcdSignature = string.Empty;

        _timer = new System.Windows.Forms.Timer { Interval = 125 };
        _timer.Tick += (_, _) => Tick();
        _timer.Start();

        Log("SpacePilotBridge v0.4.2 started");
        Tick();
    }

    private ContextMenuStrip BuildTrayMenu()
    {
        var menu = new ContextMenuStrip();
        menu.Items.Add("Settings...", null, (_, _) => ShowSettings());
        menu.Items.Add("Show status", null, (_, _) => ShowStatusBalloon());

        var speed = new ToolStripMenuItem("Speed");
        speed.DropDownItems.Add("Faster (+)", null, (_, _) => _actions.ExecuteBuiltIn("IncreaseSensitivity"));
        speed.DropDownItems.Add("Slower (-)", null, (_, _) => _actions.ExecuteBuiltIn("DecreaseSensitivity"));
        menu.Items.Add(speed);

        var lcd = new ToolStripMenuItem("LCD screensaver");
        lcd.DropDownItems.Add("Starfield", null, (_, _) => _actions.StartScreensaver("Starfield"));
        lcd.DropDownItems.Add("Matrix", null, (_, _) => _actions.StartScreensaver("Matrix"));
        lcd.DropDownItems.Add("Bounce", null, (_, _) => _actions.StartScreensaver("Bounce"));
        lcd.DropDownItems.Add(new ToolStripSeparator());
        lcd.DropDownItems.Add("Stop", null, (_, _) => _actions.StopScreensaver());
        menu.Items.Add(lcd);

        menu.Items.Add("Refresh LCD", null, (_, _) => UpdateLcd(force: true));
        menu.Items.Add("Open log/settings folder", null, (_, _) => OpenLogFolder());
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add("Exit", null, (_, _) => ExitThread());
        return menu;
    }

    private void Tick()
    {
        DateTime now = DateTime.UtcNow;
        if (now - _lastForegroundPoll >= TimeSpan.FromMilliseconds(500))
        {
            _lastForegroundPoll = now;
            string app = ForegroundApp.GetName();
            string profile = ProfileResolver.FromForegroundName(app);
            if (!string.Equals(app, _lastApp, StringComparison.OrdinalIgnoreCase))
            {
                _lastApp = app;
                Log($"Foreground: {app}");
                _lastLcdSignature = string.Empty;
            }
            if (!string.Equals(profile, _lastProfile, StringComparison.OrdinalIgnoreCase))
            {
                _lastProfile = profile;
                _actions.SetProfile(profile);
                Log($"Profile: {profile}");
                _lastLcdSignature = string.Empty;
            }
        }

        if (_openSettingsPending)
        {
            _openSettingsPending = false;
            ShowSettings();
        }

        if (_lastPressedRaw >= 0)
        {
            int raw = _lastPressedRaw;
            _lastPressedRaw = -1;
            _settingsForm?.NotifyPhysicalButton(raw);
        }

        if (!string.IsNullOrWhiteSpace(_pendingToast))
        {
            string text = _pendingToast!;
            _pendingToast = null;
            _tray.BalloonTipTitle = "SpacePilotBridge";
            _tray.BalloonTipText = text;
            _tray.ShowBalloonTip(1200);
            _lastLcdSignature = string.Empty;
        }

        if (_actions.ScreensaverActive)
        {
            if (now - _lastAnimationWrite >= TimeSpan.FromMilliseconds(200))
            {
                _lastAnimationWrite = now;
                _lcd.ShowAnimation(_actions.ScreensaverName, _animationFrame++);
            }
        }
        else
        {
            UpdateLcd(force: false);
        }

        _tray.Text = _hub.IsConnected
            ? (_virtual.IsConnected ? $"SpacePilotBridge - ready - {_actions.Settings.Sensitivity:0.00}x" : "SpacePilotBridge - virtual HID offline")
            : "SpacePilotBridge - SpacePilot offline";
    }

    private void UpdateLcd(bool force)
    {
        if (_actions.ScreensaverActive && !force) return;
        var state = _hub.State;
        BridgeSettings s = _actions.Settings;
        string sig = $"{_lastApp}|{_lastProfile}|{_hub.IsConnected}|{_virtual.IsConnected}|{s.Sensitivity:0.00}|{s.DominantMode}|{s.RotationLocked}|{string.Join(',', state.Buttons)}";
        if (!force && sig == _lastLcdSignature && DateTime.UtcNow - _lastLcdWrite < TimeSpan.FromSeconds(10))
            return;

        if (_lcd.ShowStatus(
            _lastApp,
            _hub.IsConnected,
            _virtual.IsConnected,
            state.Buttons,
            s.Sensitivity,
            s.DominantMode,
            s.RotationLocked,
            ProfileResolver.DisplayName(_lastProfile)))
        {
            _lastLcdSignature = sig;
            _lastLcdWrite = DateTime.UtcNow;
        }
    }

    private void ShowSettings()
    {
        if (_settingsForm is null || _settingsForm.IsDisposed)
        {
            _settingsForm = new SettingsForm(_actions);
            _settingsForm.Saved += (_, _) =>
            {
                _lastLcdSignature = string.Empty;
                UpdateLcd(force: true);
            };
        }

        if (!_settingsForm.Visible) _settingsForm.Show();
        if (_settingsForm.WindowState == FormWindowState.Minimized) _settingsForm.WindowState = FormWindowState.Normal;
        _settingsForm.BringToFront();
        _settingsForm.Activate();
    }

    private void ShowStatusBalloon()
    {
        var s = _actions.Settings;
        _tray.BalloonTipTitle = "SpacePilotBridge 0.4.2";
        _tray.BalloonTipText =
            $"SpacePilot: {(_hub.IsConnected ? "connected" : "offline")}\n" +
            $"Virtual SpaceMouse: {(_virtual.IsConnected ? "connected" : "offline")}\n" +
            $"Profile: {ProfileResolver.DisplayName(_lastProfile)}\n" +
            $"Speed: {s.Sensitivity:0.00}x";
        _tray.ShowBalloonTip(2500);
    }

    private static string LogDirectory => SettingsStore.DirectoryPath;

    private static void Log(string text)
    {
        try
        {
            Directory.CreateDirectory(LogDirectory);
            File.AppendAllText(Path.Combine(LogDirectory, "bridge.log"), $"{DateTime.Now:yyyy-MM-dd HH:mm:ss.fff} {text}{Environment.NewLine}");
        }
        catch { }
    }

    private static void OpenLogFolder()
    {
        Directory.CreateDirectory(LogDirectory);
        System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("explorer.exe", LogDirectory) { UseShellExecute = true });
    }

    protected override void ExitThreadCore()
    {
        _timer.Stop();
        _settingsForm?.Dispose();
        _tray.Visible = false;
        _tray.Dispose();
        _actions.Dispose();
        _lcd.Dispose();
        _virtual.Dispose();
        _hub.Release();
        Log("SpacePilotBridge stopped");
        base.ExitThreadCore();
    }
}
