using System.Diagnostics;
using System.Runtime.InteropServices;

namespace SpacePilotBridge.App;

internal static class ForegroundApp
{
    [DllImport("user32.dll")]
    private static extern nint GetForegroundWindow();

    [DllImport("user32.dll")]
    private static extern uint GetWindowThreadProcessId(nint hWnd, out uint processId);

    public static string GetName()
    {
        try
        {
            nint hwnd = GetForegroundWindow();
            if (hwnd == 0) return string.Empty;
            GetWindowThreadProcessId(hwnd, out uint pid);
            if (pid == 0) return string.Empty;
            using var p = Process.GetProcessById((int)pid);
            return Friendly(p.ProcessName);
        }
        catch { return string.Empty; }
    }

    private static string Friendly(string processName)
    {
        string n = processName.ToLowerInvariant();
        if (n.Contains("fusion")) return "FUSION 360";
        if (n.Contains("maya")) return "MAYA";
        if (n.Contains("zbrush")) return "ZBRUSH";
        return processName;
    }
}
