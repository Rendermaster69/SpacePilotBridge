namespace SpacePilotBridge.App;

internal static class ProfileResolver
{
    public static string FromForegroundName(string app)
    {
        string n = (app ?? string.Empty).ToLowerInvariant();
        if (n.Contains("fusion")) return "fusion";
        if (n.Contains("maya")) return "maya";
        if (n.Contains("zbrush")) return "zbrush";
        return "global";
    }

    public static string DisplayName(string key) => key.ToLowerInvariant() switch
    {
        "fusion" => "Fusion 360",
        "maya" => "Maya",
        "zbrush" => "ZBrush",
        "global" => "Global",
        _ => key
    };
}
