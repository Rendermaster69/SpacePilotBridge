using System.Runtime.InteropServices;

namespace SpacePilotBridge.App;

internal static class ShortcutSender
{
    private const uint INPUT_KEYBOARD = 1;
    private const uint KEYEVENTF_KEYUP = 0x0002;

    [StructLayout(LayoutKind.Sequential)]
    private struct INPUT
    {
        public uint type;
        public InputUnion U;
    }

    [StructLayout(LayoutKind.Explicit)]
    private struct InputUnion
    {
        [FieldOffset(0)] public KEYBDINPUT ki;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct KEYBDINPUT
    {
        public ushort wVk;
        public ushort wScan;
        public uint dwFlags;
        public uint time;
        public nuint dwExtraInfo;
    }

    [DllImport("user32.dll", SetLastError = true)]
    private static extern uint SendInput(uint cInputs, INPUT[] pInputs, int cbSize);

    public static bool Send(string shortcut)
    {
        if (string.IsNullOrWhiteSpace(shortcut)) return false;
        var parts = shortcut.Split('+', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        if (parts.Length == 0) return false;

        var modifiers = new List<ushort>();
        ushort main = 0;
        foreach (string part in parts)
        {
            ushort vk = ParseKey(part);
            if (vk == 0) return false;
            if (IsModifier(vk)) modifiers.Add(vk);
            else main = vk;
        }
        if (main == 0) return false;

        var inputs = new List<INPUT>();
        foreach (ushort mod in modifiers) inputs.Add(Key(mod, false));
        inputs.Add(Key(main, false));
        inputs.Add(Key(main, true));
        for (int i = modifiers.Count - 1; i >= 0; i--) inputs.Add(Key(modifiers[i], true));
        return SendInput((uint)inputs.Count, inputs.ToArray(), Marshal.SizeOf<INPUT>()) == (uint)inputs.Count;
    }

    private static INPUT Key(ushort vk, bool up) => new()
    {
        type = INPUT_KEYBOARD,
        U = new InputUnion
        {
            ki = new KEYBDINPUT { wVk = vk, dwFlags = up ? KEYEVENTF_KEYUP : 0 }
        }
    };

    private static bool IsModifier(ushort vk) => vk is 0x10 or 0x11 or 0x12 or 0x5B;

    private static ushort ParseKey(string token)
    {
        string t = token.Trim().ToUpperInvariant();
        if (t.Length == 1 && t[0] is >= 'A' and <= 'Z') return t[0];
        if (t.Length == 1 && t[0] is >= '0' and <= '9') return t[0];
        if (t.StartsWith('F') && int.TryParse(t[1..], out int fn) && fn is >= 1 and <= 24) return (ushort)(0x70 + fn - 1);

        return t switch
        {
            "CTRL" or "CONTROL" => 0x11,
            "SHIFT" => 0x10,
            "ALT" => 0x12,
            "WIN" or "WINDOWS" => 0x5B,
            "ENTER" or "RETURN" => 0x0D,
            "ESC" or "ESCAPE" => 0x1B,
            "SPACE" => 0x20,
            "TAB" => 0x09,
            "BACKSPACE" => 0x08,
            "DELETE" or "DEL" => 0x2E,
            "INSERT" or "INS" => 0x2D,
            "HOME" => 0x24,
            "END" => 0x23,
            "PAGEUP" or "PGUP" => 0x21,
            "PAGEDOWN" or "PGDN" => 0x22,
            "LEFT" => 0x25,
            "UP" => 0x26,
            "RIGHT" => 0x27,
            "DOWN" => 0x28,
            "PLUS" => 0x6B,
            "MINUS" => 0x6D,
            _ => 0
        };
    }
}
