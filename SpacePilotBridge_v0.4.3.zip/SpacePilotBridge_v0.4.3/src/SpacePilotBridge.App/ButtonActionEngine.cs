using SpacePilotBridge.Core;

namespace SpacePilotBridge.App;

internal sealed class ButtonActionEngine : IDisposable
{
    private readonly SpacePilotHub _hub;
    private readonly object _gate = new();
    private HashSet<int> _previous = new();
    private string _profile = "global";
    private bool _suppressEscUntilRelease;

    public BridgeSettings Settings { get; private set; }
    public bool ScreensaverActive { get; private set; }
    public string ScreensaverName { get; private set; } = "Starfield";

    public event EventHandler? SettingsChanged;
    public event EventHandler? OpenSettingsRequested;
    public event EventHandler? ScreensaverChanged;
    public event Action<string>? ToastRequested;
    public event Action<int>? PhysicalButtonPressed;

    public ButtonActionEngine(SpacePilotHub hub, BridgeSettings settings)
    {
        _hub = hub;
        Settings = settings;
        _hub.StateChanged += HubOnStateChanged;
    }

    public void SetProfile(string profile)
    {
        lock (_gate) _profile = string.IsNullOrWhiteSpace(profile) ? "global" : profile;
    }

    public string CurrentProfile
    {
        get { lock (_gate) return _profile; }
    }

    public void ReplaceSettings(BridgeSettings settings)
    {
        lock (_gate) Settings = settings;
        SettingsStore.Save(Settings);
        SettingsChanged?.Invoke(this, EventArgs.Empty);
    }

    public void StartScreensaver(string name)
    {
        lock (_gate)
        {
            ScreensaverName = string.IsNullOrWhiteSpace(name) ? Settings.DefaultScreensaver : name;
            ScreensaverActive = true;
        }
        ScreensaverChanged?.Invoke(this, EventArgs.Empty);
    }

    public void StopScreensaver()
    {
        bool changed;
        lock (_gate)
        {
            changed = ScreensaverActive;
            ScreensaverActive = false;
        }
        if (changed) ScreensaverChanged?.Invoke(this, EventArgs.Empty);
    }

    /// <summary>Transforms motion only. Button mapping is handled separately.</summary>
    public SpacePilotState TransformState(SpacePilotState source)
    {
        BridgeSettings s;
        lock (_gate) s = Settings;

        double tx = source.Tx * s.Sensitivity;
        double ty = source.Ty * s.Sensitivity;
        double tz = source.Tz * s.Sensitivity;
        double rx = s.RotationLocked ? 0 : source.Rx * s.Sensitivity;
        double ry = s.RotationLocked ? 0 : source.Ry * s.Sensitivity;
        double rz = s.RotationLocked ? 0 : source.Rz * s.Sensitivity;

        if (s.DominantMode)
        {
            double[] values = { tx, ty, tz, rx, ry, rz };
            int best = 0;
            for (int i = 1; i < values.Length; i++)
                if (Math.Abs(values[i]) > Math.Abs(values[best])) best = i;
            for (int i = 0; i < values.Length; i++)
                if (i != best) values[i] = 0;
            (tx, ty, tz, rx, ry, rz) = (values[0], values[1], values[2], values[3], values[4], values[5]);
        }

        return source with { Tx = tx, Ty = ty, Tz = tz, Rx = rx, Ry = ry, Rz = rz };
    }

    public uint MapVirtualButtons(IReadOnlyCollection<int> sourceButtons)
    {
        string profile;
        bool suppressEsc;
        lock (_gate)
        {
            profile = _profile;
            suppressEsc = _suppressEscUntilRelease;
        }

        uint bits = 0;
        foreach (int raw in sourceButtons)
        {
            if (raw == 10 && suppressEsc) continue;
            ButtonBinding binding = ResolveBinding(profile, raw);
            string mode = binding.Mode.Trim();

            if (mode.Equals("Disabled", StringComparison.OrdinalIgnoreCase) ||
                mode.Equals("Shortcut", StringComparison.OrdinalIgnoreCase) ||
                mode.Equals("BuiltIn", StringComparison.OrdinalIgnoreCase))
                continue;

            int? target = null;
            if (mode.Equals("Virtual", StringComparison.OrdinalIgnoreCase))
            {
                if (VirtualSpaceMouseButtons.ByName.TryGetValue(binding.Value, out int customBit))
                    target = customBit;
                else if (int.TryParse(binding.Value, out customBit) && customBit is >= 0 and < 32)
                    target = customBit;
            }
            else // Default / Inherit fallback
            {
                target = SpacePilotButtons.GetDefaultVirtualBit(raw);
            }

            if (target is >= 0 and < 32) bits |= 1u << target.Value;
        }
        return bits;
    }

    public ButtonBinding ResolveBinding(string profile, int raw)
    {
        lock (_gate)
        {
            if (!profile.Equals("global", StringComparison.OrdinalIgnoreCase) &&
                Settings.Profiles.TryGetValue(profile, out var p) &&
                p.Buttons.TryGetValue(raw, out var appBinding) && !appBinding.IsEmpty)
                return Clone(appBinding);

            if (Settings.Profiles.TryGetValue("global", out var global) &&
                global.Buttons.TryGetValue(raw, out var globalBinding) && !globalBinding.IsEmpty)
                return Clone(globalBinding);
        }
        return ButtonBinding.Default();
    }

    private void HubOnStateChanged(object? sender, SpacePilotState state)
    {
        var current = state.Buttons.ToHashSet();
        int[] pressed;
        bool escReleased;
        lock (_gate)
        {
            pressed = current.Except(_previous).ToArray();
            escReleased = _suppressEscUntilRelease && !current.Contains(10);
            _previous = current;
            if (escReleased) _suppressEscUntilRelease = false;
        }

        foreach (int raw in pressed)
        {
            PhysicalButtonPressed?.Invoke(raw);
            HandlePress(raw);
        }
    }

    private void HandlePress(int raw)
    {
        if (raw == 10)
        {
            bool wasScreensaver;
            lock (_gate)
            {
                wasScreensaver = ScreensaverActive;
                if (wasScreensaver)
                {
                    ScreensaverActive = false;
                    _suppressEscUntilRelease = true;
                }
            }
            if (wasScreensaver)
            {
                ScreensaverChanged?.Invoke(this, EventArgs.Empty);
                ToastRequested?.Invoke("LCD screensaver stopped");
                return;
            }
        }

        string profile;
        lock (_gate) profile = _profile;
        ButtonBinding binding = ResolveBinding(profile, raw);

        if (binding.Mode.Equals("Shortcut", StringComparison.OrdinalIgnoreCase))
        {
            if (ShortcutSender.Send(binding.Value))
                ToastRequested?.Invoke($"{SpacePilotButtons.GetName(raw)} -> {binding.Value}");
            return;
        }

        if (binding.Mode.Equals("BuiltIn", StringComparison.OrdinalIgnoreCase))
            RunBuiltIn(binding.Value);
    }

    public void ExecuteBuiltIn(string action) => RunBuiltIn(action);

    private void RunBuiltIn(string action)
    {
        BridgeSettings settings;
        lock (_gate) settings = Settings;
        string a = (action ?? string.Empty).Trim();
        switch (a.ToLowerInvariant())
        {
            case "increasesensitivity":
                settings.Sensitivity = Math.Clamp(Math.Round(settings.Sensitivity + settings.SensitivityStep, 2), 0.10, 3.00);
                SaveAndNotify($"Speed {settings.Sensitivity:0.00}x");
                break;
            case "decreasesensitivity":
                settings.Sensitivity = Math.Clamp(Math.Round(settings.Sensitivity - settings.SensitivityStep, 2), 0.10, 3.00);
                SaveAndNotify($"Speed {settings.Sensitivity:0.00}x");
                break;
            case "toggledominant":
                settings.DominantMode = !settings.DominantMode;
                SaveAndNotify($"Dominant {(settings.DominantMode ? "ON" : "OFF")}");
                break;
            case "togglerotationlock":
                settings.RotationLocked = !settings.RotationLocked;
                SaveAndNotify($"Rotation {(settings.RotationLocked ? "LOCKED" : "FREE")}");
                break;
            case "opensettings":
                OpenSettingsRequested?.Invoke(this, EventArgs.Empty);
                break;
            case "startstarfield": StartScreensaver("Starfield"); break;
            case "startmatrix": StartScreensaver("Matrix"); break;
            case "startbounce": StartScreensaver("Bounce"); break;
            case "stopscreensaver": StopScreensaver(); break;
        }
    }

    private void SaveAndNotify(string message)
    {
        SettingsStore.Save(Settings);
        SettingsChanged?.Invoke(this, EventArgs.Empty);
        ToastRequested?.Invoke(message);
    }

    private static ButtonBinding Clone(ButtonBinding b) => new() { Mode = b.Mode, Value = b.Value };

    public void Dispose()
    {
        _hub.StateChanged -= HubOnStateChanged;
    }
}
