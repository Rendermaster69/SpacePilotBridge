# SpacePilotBridge v0.4.3

Windows bridge for the original **3Dconnexion SpacePilot (046D:C625)**.

The physical SpacePilot is read directly over HID and exposed to current 3DxWare as a virtual **SpaceMouse Pro Wireless-class device (256F:C631)**. 6DOF motion stays native HID; there is no mouse-motion or keyboard emulation for navigation.


## v0.4.3 upgrade fix

`Upgrade-App-Only.cmd` now force-stops both current and older SpacePilotBridge process names and waits until Windows has released the installed EXE before replacing it. This fixes the `Copy-Item ... file is being used by another process` error seen when upgrading a running tray instance.

## What is new in v0.4

- Correct sparse SpaceMouse Pro button bitmap. The previous build treated most target buttons as sequential bits; current 3DxWare uses sparse button positions.
- Physical **Speed + / Speed -** now change bridge sensitivity from 0.10x to 3.00x.
- Physical **Dominant** toggles strongest-axis-only motion.
- Physical **Config** opens the SpacePilotBridge settings window.
- Physical buttons that do not exist on the modern SpaceMouse Pro (`5`, `6`, `Left`, `+`, `-`, `Dominant`, `Config`) are now available for custom software actions instead of being silently discarded.
- Per-application button profiles for **Global, Fusion 360, Maya and ZBrush**.
- Button behavior can be `Default`, `Virtual`, `Shortcut`, `BuiltIn`, `Disabled`, or inherited from Global.
- App shortcuts are only used for buttons you explicitly configure as `Shortcut`; 6DOF movement still goes through the virtual HID driver.
- New crisp **5x7 monochrome pixel font** for the original 240x64 SpacePilot LCD.
- LCD status page now shows active app, profile, sensitivity, dominant mode, rotation lock and pressed buttons.
- LCD screensavers: **Starfield, Matrix and Bounce**.
- Screensavers stay active until you stop them from the tray/settings window or press the physical SpacePilot **Esc** button. That Esc press is swallowed while stopping a screensaver.
- Custom SpacePilotBridge tray/application icon.
- App publishes as one **self-contained single-file `SpacePilotBridge.exe`**.
- Single-instance protection prevents duplicate tray icons.

## Recommended upgrade from a working v0.3.3

If your v0.3.3 virtual driver already works, you do **not** need to rebuild or reinstall it.

1. Extract this ZIP.
2. Double-click **`Upgrade-App-Only.cmd`**.
3. Approve the administrator prompt.
4. The script builds the v0.4 single-file exe, replaces `C:\Program Files\SpacePilotBridge\SpacePilotBridge.exe`, leaves the existing virtual HID driver untouched, and starts v0.4.

Your settings are stored separately in:

`%LOCALAPPDATA%\SpacePilotBridge\settings.json`

## Full setup

Use **`Setup.cmd`** only when installing from scratch or when the virtual HID driver is missing/broken. It builds the app, builds/signs the virtual HID driver and installs the package.

The driver build still requires Visual Studio/Build Tools + Windows SDK + WDK because Windows virtual HID is a driver-level component.

## Tray app

Double-click the SpacePilotBridge tray icon to open Settings.

Tray menu:

- Settings
- Show status
- Speed -> Faster / Slower
- LCD screensaver -> Starfield / Matrix / Bounce / Stop
- Refresh LCD
- Open log/settings folder
- Exit

## Button mapping

Open **Settings -> Button mapping** and choose a profile.

### Behavior modes

- **Inherit**: use the Global profile.
- **Default**: use the verified physical SpacePilot -> modern SpaceMouse mapping when the target has an equivalent button.
- **Virtual**: send a specific modern SpaceMouse button. Assignment examples: `Menu`, `Fit`, `Top`, `Right`, `Front`, `Roll CW`, `1`, `2`, `3`, `4`, `Esc`, `Alt`, `Shift`, `Ctrl`, `Rotation lock`.
- **Shortcut**: send a Windows keyboard shortcut only when that physical button is pressed. Examples: `F`, `Ctrl+S`, `Shift+F`, `Ctrl+Shift+S`, `F5`.
- **BuiltIn**: run a SpacePilotBridge action.
- **Disabled**: do nothing.

### Built-in actions

- `IncreaseSensitivity`
- `DecreaseSensitivity`
- `ToggleDominant`
- `ToggleRotationLock`
- `OpenSettings`
- `StartStarfield`
- `StartMatrix`
- `StartBounce`
- `StopScreensaver`

Default software-only bindings:

- Speed + -> IncreaseSensitivity
- Speed - -> DecreaseSensitivity
- Dominant -> ToggleDominant
- Config -> OpenSettings

### Verified default virtual mapping

The modern target uses a sparse 32-bit button report. Shared physical keys are mapped by meaning, not by sequential bit number:

- Panel -> Menu
- Fit -> Fit
- Top -> Top
- Right -> Right
- Front -> Front
- 1..4 -> 1..4
- Esc -> Esc
- Alt -> Alt
- Shift -> Shift
- Ctrl -> Ctrl
- 3D Lock -> Rotation lock

The old SpacePilot `5`, `6`, `Left`, `+`, `-`, `Dominant` and `Config` keys do not have direct equivalents on the emulated SpaceMouse Pro Wireless and are therefore exposed to the v0.4 software mapping layer.

## LCD

The physical SpacePilot LCD is 240x64 monochrome. v0.4 draws its own 1-bit pixel font instead of rendering a Windows anti-aliased font and thresholding it, which makes small text considerably cleaner on the original panel.

Screensavers are manually started from the tray menu or Settings. They do not time out automatically.

## Diagnostics

`Run-Diagnostics.cmd` checks:

- physical SpacePilot input
- virtual 256F:C631 HID availability
- 3DxWare processes
- physical LCD writes
- live six-axis values and raw physical button IDs

Logs and settings live in:

`%LOCALAPPDATA%\SpacePilotBridge`

## Notes

SpacePilotBridge is an independent interoperability project. 3Dconnexion, SpacePilot and SpaceMouse are trademarks of their respective owner. Current 3DxWare is not redistributed by this project.
