SpacePilotBridge v0.4.1 is an independent interoperability project for the original
3Dconnexion/Logitech SpacePilot (046D:C625).

Protocol behavior and compatibility were cross-checked against public sources:

- OpenNDOF (MIT, with its own NOTICE): original SpacePilot raw HID reports and
  240x64 monochrome LCD feature-report protocol.
  https://github.com/bpmcgill/OpenNDOF

- FreeCAD (LGPL/GPL project; no source copied here): public Windows Raw Input
  mappings documenting pre-2009 SpacePilot button meanings and current
  3Dconnexion virtual-key meanings.
  https://github.com/FreeCAD/FreeCAD

- Microsoft Windows Driver Samples: the build scripts download and patch the
  official `hid/vhidmini2` sample on the user's Windows machine. That downloaded
  sample remains under Microsoft's license contained in that repository.
  https://github.com/microsoft/Windows-driver-samples

- Public SpaceMouse interoperability research documenting the common six-axis
  +/-350 HID convention and current-driver acceptance of SpaceMouse-class HID
  reports. No source code from non-commercial repositories is included here.

3Dconnexion, SpacePilot, SpaceMouse and 3DxWare are trademarks of their
respective owner. This project is not affiliated with, endorsed by, or
supported by 3Dconnexion.
